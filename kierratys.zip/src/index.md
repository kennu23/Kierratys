<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Keräyspisteet Kartalla</title>
  <link rel="stylesheet" href="node_modules/leaflet/dist/leaflet.css">
  <style>
    #map {
      height: 400px;
      width: 100%;
    }
  </style>
</head>
<body>
  <div id="map"></div>
  <p>Kartta</p>
</body>
<script src="kierratysinfo.js"></script>
</html>
