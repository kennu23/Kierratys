function Home() {
    return (
        <div>
            <h1>Kierratys</h1>
            <p>tämä sivu on tarkoitettu kierrätyskeskusten etsimiseksi</p>
        </div>
        
    )
}

export default Home